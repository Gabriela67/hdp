alert("hola")
for(var index=1 ; index<= 10; index++){

    var resultado='';

    for (let j = 1 ;j <= index ; j++) {
        resultado +='* '
        
    }
    console.log(resultado)
}